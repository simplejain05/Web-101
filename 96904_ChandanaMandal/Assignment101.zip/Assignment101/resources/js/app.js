//----------SHOPPING BAG CONTROLLER -----------------------
/*
* Assumptions: To make it simple I am assuming that promocode is applied to entire shopping bag, not individual products
*/
var shoppingBagController = ( function ( ) {
    var product, promo, colors, data;
    
    product = function (id, desc, style, color, price, img, size, quantity, colors) {
        this.id = id;
        this.description = desc;
        this.style = style;
        this.color = color;
        this.price = price;
        this.image = img;
        this.size = size;
        this.quantity = quantity;
        this.colorList = colors;
    }; 
    
    promo = function ( id, code, amount, unit ) {
        this.id = id;
        this.code = code;
        this.amount = amount;
        this.unit = unit;
    }; 
    
    colors = function(name, code) {
        this.colorName = name;
        this.colorCode = code;
    };    
    
    //complete shopping data
    data = {
        selectedProduct: [],
        promocodes: [],
        appliedPromo : '',
        discount: 0,
        deliveryCharges: 0,
        totalSum: 0,
        estimatedTotal: 0
    };
    
    //Add the product's prices and update data
    var calculatePrice = function ( ) {
        var sum = 0;
        data.selectedProduct.forEach(prod => {
            sum += parseFloat(prod.price) * parseInt(prod.quantity);
        });  
        
        data.totalSum = sum;
        
        //Calculate discount
        calculateDiscount();
        
        //delivery charges of $50 applies if the total amount is less then $50
        if(sum > 50){
                data.deliveryCharges = 0;
        }else {
            data.deliveryCharges = 10;
        }        
        
        //Calculate estimated sum
        data.estimatedTotal = data.totalSum + data.deliveryCharges - data.discount;
        
        return {
            totalSum: data.totalSum,
            discount: data.discount,
            deliveryCharges: data.deliveryCharges,
            estimatedSum: data.estimatedTotal
        }
    };
    
    //Calculate discount for applied promocode
    var calculateDiscount = function(){
        let isPresent = false;
        let currPromo = data.appliedPromo;
        let discount = 0;
        data.promocodes.forEach(promo => {
            if(!isPresent && promo.code == currPromo){
                isPresent = true;
                
                if(promo.unit === 'substract'){
                    discount = promo.amount; 
                }else if(promo.unit === 'percentage'){
                    //alert("total sum is " + promo.unit);
                    discount = (parseFloat(data.totalSum) * parseFloat(promo.amount)) / 100;
                }
                
                data.discount = discount;
            };
        })
    };
    
    var getIndexOfItem = function(productId) {
        var index = 0, itemIndex = 0;

        data.selectedProduct.forEach(prod => {
            if(prod.id === parseInt(productId)){
                itemIndex = index;
            }  
            index++;
        });
            
        return itemIndex;
    };
    
    return {
        //This method is used to fill in the initial data on page
        GetShoppingBag: function() {
            var color1, color2, color3, color4, color5, color6;
            
            data.selectedProduct.push(new product(1, 'Bold green cotton shirt', 'MS13kt1809', 'Blue', 29, './resources/img/item-img-1.jpg', 'S', 1, []));
            data.selectedProduct.push(new product(2, 'Black green cotton shirt', 'MS13kt1809', 'Black', 2, './resources/img/item-img-2.jpg', 'S', 1, []));
            data.selectedProduct.push(new product(3, 'Bold green cotton shirt', 'MS13kt1809', 'Red', 35, './resources/img/item-img-3.jpg', 'S', 1, []));
            
            calculatePrice();
            
            //Add color details to products
            color1 = new colors('olive green', '#82E0AA');
            color2 = new colors('SALMON', '#FA8072');
            color3 = new colors('BLUE', '#0000FF');
            color4 = new colors('PURPLE', '#800080');
            color5 = new colors('OLIVE', '#808000');
            color6 = new colors('YELLOW', '#FFFF00');
            data.selectedProduct[0].colorList.push(color1);
            data.selectedProduct[0].colorList.push(color2);
            data.selectedProduct[1].colorList.push(color3);
            data.selectedProduct[1].colorList.push(color1);
            data.selectedProduct[1].colorList.push(color4);
            data.selectedProduct[2].colorList.push(color5);
            data.selectedProduct[2].colorList.push(color1);
        },
        
        //This method is used to fill in initial promocodes
        updatePromocodes: function(){
            data.promocodes.push(new promo(1, 'JF10', 5, 'percentage'));
            data.promocodes.push(new promo(2, 'KB05', 15, 'substract'));
            data.promocodes.push(new promo(3, 'MayDay', 5, 'substract'));
            
            data.appliedPromo = 'JF10';
        },
        
        // this method is used to add product to shopping bag
        addItemToBag: function(desc, style, color, price, img, size, quantity) {
            //calculate id
            let id = data.selectedProduct.length + 1;
            
            //create new object
            let newProduct = new product(id, desc, style, color, price, img, size, quantity)
            
            //add object to shopping bag
            this.data.selectedProduct.push(newProduct);
            
            //Calculate and update discount and total price
            calculatePrice();
            
        }, 
        
        removeItemFromBag: function (id) { 
            var prdIndex = getIndexOfItem(id);
            
            data.selectedProduct.splice(prdIndex, 1);
        },
        
        
        //public method to update prices
        updatedPrices: function() {
            return calculatePrice();            
        },
        
        getDefaultProducts: function(){
            var arr = [];
            data.selectedProduct.forEach(pr => arr.push(pr));
            
            //console.log(arr);
            return arr;
        },
        
        //Get product details based on product id
        getProductById: function(id){
            var prodId = 0;
            var product;
            
            data.selectedProduct.forEach(prod => {
                if(prod.id === parseInt(id)){
                    prodId = parseInt(id);
                    product = prod;
                }   
                
            });
            
            if(prodId === 0)
                return null;
            else {
                return product;
            }
        },
                
        //User has updated product quantity
        updateProductQuantity: function(objProduct){
            var prodId = 0;
            var product;
            
            data.selectedProduct.forEach(prod => {
                if(prod.id === objProduct.id){
                    product = prod;
                }                   
            });
            
            //PENDING : To find index of the product in teh array
            
            //Assumption that id is in sequence
            data.selectedProduct[product.id + 1] = product;
        },
        
        //User has updated product quantity
        updateProductDetails: function(objProduct){
            var prodId = 0;
            var index = 0;
            var itemIndex = 0;
            var product;
            
            data.selectedProduct.forEach(prod => {
                if(prod.id === objProduct.id){
                    product = prod;
                    itemIndex = index;
                }  
                index++;
            });
            
            //PENDING : To find index of the product in teh array
            
            //Assumption that id is in sequence
            data.selectedProduct[itemIndex] = product;
        },
        
        getAllProducts: function() {
            return data.selectedProduct;
        },
        
        //just for testing purpose
        testing: function() {
            console.log(data);
        }
        
    };
        
    
})();


//----------UI CONTROLLER ---------------------------------
var UIController = (function(){
    var DOMStrings = {
        productlist: "product-list",
        totalSum: ".text_total",
        discount: ".text_discount",
        deliveryCharges: ".text_deliveryCharges",
        estimatedSum: ".text_estimatedTotal",
        productListContainer: ".product-list",
        txtPricesValSubstr: "productPrice_",
        txtQuantityIdSubstr: "qty_",
        txtEditOverlay: "edit_overlay_",
        txtRemOverlay: "rem_overlay_",
        txtSaveOverlay: "save_overlay_",
        overlayContainer: ".overlay",
        overlayClose: ".close",
        overlayEditSave: ".btn_edit_product",
        elPrColorName: ".pr-colorName",
        elPrDesc: ".pr-desc",
        elPrPrice: ".pr-price",
        elPrColorList: ".pr-colorList",
        elPrImageLarge: ".pr-img-large",
        elSelectSize: "select_size",
        elSelectQuantity: "select_quantity",
        ulColors: ".ul-colors",
        colorid: "colorid_"
    };
    
    return {
        // This method is used to add product information rows on the UI
        //%SizeMobile%   PriceMobile    QuantityMobile
        //
        addProductItem: function(obj){
            var html, newHtml, el, price;
            
            html = '<div class="row clearfix"><div><div class="col span-1-of-6 col-div"><img src="%image%" alt="%description%"></div><div class="col span-2-of-6 col-desc"><h2>%description%</h2><p>Style #: %style%<br> Color: %color%</p><p class="for-mobile">Size: %SizeMobile%</p><br><p class="for-mobile">Quantity : %QuantityMobile%</p><br><p class="for-mobile item-price"><span class="currency">$</span>%PriceMobile%</p> <div class="cls_buttons x-mobile">   <a href="#" id="%edit_overlay_id%">EDIT</a> &nbsp;|&nbsp;<a href="#" id="%rem_overlay_id%">x&nbsp;REMOVE</a>&nbsp;|&nbsp;     <a href="#" id="%save_overlay_id%">SAVE FOR LATER</a></div></div><div class="col span-1-of-6 col-div x-mobile"><h3>%size%<h3></div> <div class="col span-1-of-6 col-div x-mobile"><h3><input type="text" value="%quantity%" id="qty_%id%"></h3></div><div class="col span-1-of-6 col-div x-mobile"><h3><span class="currency">$</span><span class="productPrice_%id%">%price%</span></h3></div></div><div><div class="cls_buttons for-mobile"><a href="#" id="%edit2_overlay_id%">EDIT</a> &nbsp;|&nbsp;<a href="#" id="%rem2_overlay_id%">x&nbsp;REMOVE</a>&nbsp;|&nbsp;<a href="#" id="%save2_overlay_id%">SAVE FOR LATER</a></div></div>';
          
            
            price = parseFloat(obj.price) * parseInt(obj.quantity);
            
            newHtml = html.replace('%image%', obj.image);
            newHtml = newHtml.replace('%description%', obj.description.toUpperCase());
            newHtml = newHtml.replace('%description%', obj.description.toUpperCase());
            newHtml = newHtml.replace('%color%', obj.color.toUpperCase());
            newHtml = newHtml.replace('%style%', obj.style.toUpperCase());
            newHtml = newHtml.replace('%size%', obj.size.toUpperCase());
            newHtml = newHtml.replace('%SizeMobile%', obj.size.toUpperCase());
            newHtml = newHtml.replace('%price%', price);
            newHtml = newHtml.replace('%PriceMobile%', price);
            newHtml = newHtml.replace('%quantity%', obj.quantity);
            newHtml = newHtml.replace('%QuantityMobile%', obj.quantity);
            newHtml = newHtml.replace('%id%', obj.id);
            newHtml = newHtml.replace('%id%', obj.id);
            newHtml = newHtml.replace('%edit_overlay_id%', DOMStrings.txtEditOverlay + obj.id);
            newHtml = newHtml.replace('%rem_overlay_id%', DOMStrings.txtRemOverlay + obj.id);
            newHtml = newHtml.replace('%save_overlay_id%', DOMStrings.txtSaveOverlay + obj.id);
            
            el = document.getElementById(DOMStrings.productlist);
            
            if(el !== undefined){
                el.insertAdjacentHTML('beforeend',newHtml);
            }
            
        },
        
        addTableHeader: function (count) {
            var html, newHtm, el;
            
            html = '<div class="row col-header col-border x-mobile"><div class="col span-1-of-6 col-div">%count% ITEMS</div><div class="col span-2-of-6 col-desc">&nbsp;</div><div class="col span-1-of-6 col-div">SIZE</div><div class="col span-1-of-6 col-div">QTY</div><div class="col span-1-of-6 col-div">PRICE</div>';
            
            newHtml = html.replace('%count%', count);
            
            el = document.getElementById(DOMStrings.productlist);
            if(el !== undefined){
                el.insertAdjacentHTML('afterbegin',newHtml);
            }
            
        },
        
        displayProductColors: function (colors) {
            var html, newHtm, el, index = 0;

            el = document.querySelector(DOMStrings.ulColors);
            
            //clear existing LIs
            while(el.firstChild){
                el.removeChild(el.firstChild);
            }
            
            colors.forEach(clr => {
                html = '<li data-value=%product_name%><span class="colorbox" id="%colorid%" style="background-color:%product_color%"></span></li>';            
                newHtml = html.replace('%product_color%', clr.colorCode);
                newHtml = newHtml.replace('%product_name%', "'" + clr.colorName.toUpperCase()+ "'");
                newHtml = newHtml.replace('%colorid%', "colorid_" + index);
                
                if(el !== null){
                    el.insertAdjacentHTML('beforeend',newHtml);
                }
                
                index++;
            })
        },
        
        clearDisplay: function ( ) {
            
            el = document.getElementById(DOMStrings.productlist);
            while (el.firstChild) {
                el.removeChild(el.firstChild);
            }         
        },
        

        //display product details on overlay
        displayProductDetails: function(obj){
            
            document.querySelector(DOMStrings.elPrDesc).textContent = obj.description.toUpperCase();
            document.querySelector(DOMStrings.elPrImageLarge).childNodes[1].src = obj.image;
            document.querySelector(DOMStrings.elPrColorName).textContent = obj.color.toUpperCase();
            document.querySelector(DOMStrings.elPrPrice).textContent = obj.price;
            document.getElementById(DOMStrings.elSelectSize).value = obj.size;
            document.getElementById(DOMStrings.elSelectQuantity).value = obj.quantity;
            document.querySelector(DOMStrings.overlayEditSave).value = obj.id;
            
            this.displayProductColors(obj.colorList);
            
        },
        
        //display calculated sum and related details on bottom of page
        displayCalculatedPrices: function(obj){
                        
            //Updated the display of Summary section based on actual calculations
            document.querySelector(DOMStrings.totalSum).textContent = obj.totalSum;
            document.querySelector(DOMStrings.discount).textContent = obj.discount;
            document.querySelector(DOMStrings.deliveryCharges).textContent = obj.deliveryCharges;
            document.querySelector(DOMStrings.estimatedSum).textContent = obj.estimatedSum;
            
        },
        
        //Get edited product information on Overlay edit screen
        GetUpdatedInformation: function (prd) {
            
            //Read information for size, quantity and color            
            prd.size = document.getElementById(DOMStrings.elSelectSize).value;
            prd.quantity = document.getElementById(DOMStrings.elSelectQuantity).value;
            
            var elColors = document.querySelector(DOMStrings.elPrColorList).getElementsByClassName('selected');
            
            if(elColors.length > 0){
                var col = elColors[0].getAttribute('data-value');            
                prd.color = col;
            }
            
            return prd;
        },
        
        hideOverlay: function () {
            document.querySelector(DOMStrings.overlayContainer).style.display = 'none';
        },
        
        displayOverlay: function () {
            document.querySelector(DOMStrings.overlayContainer).style.display = 'block';
        },
        
        updateColorSelection: function (index) {
            var liElements;
            
            liElements = document.querySelector(DOMStrings.ulColors).getElementsByTagName('li');
            
            Array.from(liElements).forEach(li => li.classList.remove('selected'));
            
            liElements[index].classList.add('selected');
            
            document.querySelector(DOMStrings.elPrColorName).innerHTML = liElements[index].getAttribute('data-value');
                        
        },
        
        getDOMString: function(){
            return DOMStrings;
        }
    };
    
    
    
})();


//----------CONTROLLER ------------------------------------

var controller = (function(sBagCtrl, uiCtrl){
    
    var DOMStrings = uiCtrl.getDOMString(),
    
    initializeProducts = function(){
        var products = sBagCtrl.getDefaultProducts();
        
        refreshPage(products);
        
        /*uiCtrl.addTableHeader(products.length);
        
        //console.log(products);
        products.forEach(prod => {
            //console.log(prod);
            uiCtrl.addProductItem(prod);
        } );
        
        var prices = sBagCtrl.updatedPrices();
        //console.log(prices);
        uiCtrl.displayCalculatedPrices(prices);*/
    },
        
    refreshPage = function(products) {
        //clear products display
        uiCtrl.clearDisplay();
        
        //Reload page with updated products
        uiCtrl.addTableHeader(products.length);
        
        products.forEach(prod => {
           
            uiCtrl.addProductItem(prod);
        } );
        
        var prices = sBagCtrl.updatedPrices();
        
        uiCtrl.displayCalculatedPrices(prices);
    },
    
    //This method is call when the quantity of a product is changed on screen
    updateProductPrice = function(event){
        var itemId, productId, productPrice, calculatedPrice;
        //Get id  and value of the product whose quantity is changed
        itemId = event.target.id;
        productId = itemId.replace(DOMStrings.txtQuantityIdSubstr, '');
        var updatedQuantity = document.getElementById(itemId).value;
        //console.log(updatedQuantity);
        
        //Get product details from shopping Bag controller
        var product = sBagCtrl.getProductById(productId);
        
        //Calculate update price for the product for the quantity
        productPrice = product.price;
        calculatedPrice = parseFloat(product.price) * parseInt(updatedQuantity);
        
        //display updated product price
        document.querySelector('.' + DOMStrings.txtPricesValSubstr + productId).textContent = calculatedPrice;
                
        //Save updated data to the shopping bag
        product.quantity = parseInt(updatedQuantity);
        
        sBagCtrl.updateProductDetails(product);        
        
        //Caluculate prices and display           
        var prices = sBagCtrl.updatedPrices();
        uiCtrl.displayCalculatedPrices(prices);
        
    },
    
    editProduct = function ( event ) {
        
        //Get Item id from event        
        itemId = event.target.id;
        
        if(itemId.indexOf(DOMStrings.txtEditOverlay) != -1){

            productId = itemId.replace(DOMStrings.txtEditOverlay, '');

            //Get product using Id
            var product = sBagCtrl.getProductById(productId);        

            //use product to fill in overlay
            uiCtrl.displayProductDetails(product);

            //display overlay and dim background
            //document.querySelector(DOMStrings.overlayContainer).style.display = 'block';
            uiCtrl.displayOverlay();
        }
    },
    
    removeProduct = function ( event ) {
        var itemId, prdId;
        itemId = event.target.id;
        if(itemId.indexOf(DOMStrings.txtRemOverlay) != -1){
             
            //Identify product id
            prdId = itemId.replace(DOMStrings.txtRemOverlay, '');
            
            //Call shopping Bag controller to remove item
            sBagCtrl.removeItemFromBag(prdId);

            //update ui display
            refreshPage(sBagCtrl.getAllProducts());
        }
    },
    
    saveProductForLater = function ( ) {
        
        var itemId = event.target.id;
         if(itemId.indexOf(DOMStrings.txtSaveOverlay) != -1){
           alert('This feature would be available soon!!!')     
        }
    },
    
    closeOverlay = function () {
                
        uiCtrl.hideOverlay();
    },
    
    //Save information updated on overlay screen
    saveEditedProduct = function (event) {
        
        var prodId, product, prd, allProducts;

        //Read changed values for: productID, color, size, quantity
        prodId = event.target.value;

        //Get product using Id
        product = sBagCtrl.getProductById(prodId);
                
        prd = uiCtrl.GetUpdatedInformation(product);
        sBagCtrl.updateProductDetails(prd);
        
        allProducts = sBagCtrl.getAllProducts();
        
        refreshPage(allProducts);
        
        uiCtrl.hideOverlay();
        
    },
        
    changeColor = function(event) {
        var selectionId, index;
        
        selectionId = event.target.id;
        index = selectionId.replace(DOMStrings.colorid, '');
        
        //Call ui method to updated selected value of colors
        uiCtrl.updateColorSelection(index);
        
    },
        
    setupEventListeners = function() {
        
        //event listener for product quantity change item
        document.querySelector(DOMStrings.productListContainer).addEventListener('change', updateProductPrice);
        
        //event listener for EDIT | REMOVE | SAVE FOR LATER buttons
        document.querySelector(DOMStrings.productListContainer).addEventListener('click', editProduct);
        document.querySelector(DOMStrings.productListContainer).addEventListener('click', removeProduct);
        document.querySelector(DOMStrings.productListContainer).addEventListener('click', saveProductForLater);   
        
        //close and edit/save event handlers
        document.querySelector(DOMStrings.overlayClose).addEventListener('click', closeOverlay);
        document.querySelector(DOMStrings.overlayEditSave).addEventListener('click', saveEditedProduct);
        
        //color selection change event
        document.querySelector(DOMStrings.elPrColorList).addEventListener('click', changeColor);
        
    };
    
    return {
        init: function() {
            
            console.log('Application has started.');
            setupEventListeners();
            sBagCtrl.GetShoppingBag();
            sBagCtrl.updatePromocodes();            
            sBagCtrl.updatedPrices(); 
            initializeProducts();
            //sBagCtrl.testing();
        }
    };
    
})(shoppingBagController, UIController);

controller.init();