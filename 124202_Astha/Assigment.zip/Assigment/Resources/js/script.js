// PRODUCT CONTROLLER

     var productController = (function(){
      //Define Products
     var Product = function(id,image,title, style, color,size,quantity,price,discount,overlayImage) {
        this.id=id;
        this.image=image;
        this.title = title;
        this.style = style;
        this.color = color;
        this.quantity=quantity;
        this.price = price;
        this.discount = discount;
        this.size=size;
        this.overlayImage=overlayImage;
        
    };
    
    var data ={
        products:[]
    };
    
    // Dummy product objects
    var product1 = new Product('Prod1','resources/img/Product1.png','SOLID BLUE COTTON TSHIRT','MS13KT1906','Blue','M',1,11.00,10,'resources/img/prod1-big.png');
    var product2 = new Product('Prod2','resources/img/product2.png','PINK RAINBOW PRINT GIRLS','MS13KT1906','Pink','S',1,17.00,10,'resources/img/prod2-big.png');
    var product3 = new Product('Prod3','resources/img/product3.png','BLUE FLOWER PATTERN SHIRT','MS13KT1906','Blue','L',3,09.00,10,'resources/img/prod3-big.png');
    data.products.push(product1);
    data.products.push(product2);
    data.products.push(product3);
    
    //method to get product index by poduct ID
    var getProdIndexById = function(id){
    var ids,index;
    ids = data.products.map(function(current){
    return current.id;
    });
    index = ids.indexOf(id);
    return index;
    };
    
    //Return product controller methods  
    //Return product data     
    return{
    addProduct:function(){
    return data;
    },
        
    //Delete product by product id  
    deleteItem: function(id){
    var index = getProdIndexById(id);
    if (index !== -1){
    data.products.splice(index, 1);
    return data;
    }
    },
    
    //method to get product by poduct ID
    getProductByID: function(id){
    var index = getProdIndexById(id);
    if (index !== -1) {
    return data.products[index];
    }
    },
    
    //Update product after edit   
    updateProductDetails: function(id,size,quantity){
    var index = getProdIndexById(id);
    if(index !== -1){
    data.products[index].size=size;
    data.products[index].quantity=quantity;
    return data;
    }
    },
    //calculate total
    calculateTotal: function(){
        var total=0;
         data.products.forEach(function(cur){
             total= total+cur.price*cur.quantity;
              });
        return total;
     }   
        
        
    };
    })();



    // UI CONTROLLER
    var UIController = (function(){
    //DOM Strings
    var DOMstrings={
    productContainer:'.products', 
    removebutton:'.remove',
    editbutton:'.edit',
    editOverlay:'.edit-button',
    selctSizeId:'select-size',
    selectQuantityId:'select-quantity',
    close:'close',
    overlayId:'overlayId',
    productList:'product-list',
    messageId:'noProducts',
    noOfItems:'noOfItems',
    overlayImageId:'overlayImage',
    total:'total',
    estimatedTotal:'estimated-total'    
    };
    
    //Display each product 
    var displayProducts= function(obj){
    var html,newHtml,element;
    element=DOMstrings.productContainer;
    html='<div class="row product" id=%id%><div class="col span-2-of-7"><span class="image"><img src=%image% alt="Lisbon"></span></div><div class="col span-2-of-7"><div><h2>%title%</h2>Style #:<span>%style%</span><br>Colour:<span>%color%</span></div><br><br><br><div class="actions"><span class="edit">EDIT  </span>|<span class="remove">  X REMOVE  </span>|<span>  SAVE FOR LATER</span></div></div><div class="col span-1-of-7"><span class="size">%size%</span></div><div class="col span-1-of-7"><div class="qty"><span class="box">%quantity%</span></div></div><div class="col span-1-of-7"><span class="last"><sup>$</sup>%price%</span></div></div>'
    // Replace the placeholder text with some actual data
    newHtml = html.replace('%id%', obj.id);
    newHtml = newHtml.replace('%image%', obj.image);
    newHtml = newHtml.replace('%title%', obj.title);
    newHtml = newHtml.replace('%style%', obj.style);
    newHtml = newHtml.replace('%color%', obj.color);
    newHtml = newHtml.replace('%size%', obj.size);
    newHtml = newHtml.replace('%quantity%', obj.quantity);
    newHtml = newHtml.replace('%price%', obj.price.toFixed(2));
    // Insert the HTML into the DOM
    document.querySelector(element).insertAdjacentHTML('beforeend', newHtml);  
    };
        
    //Return UI controller methods
    //Return method to display product    
    return{
    displayProdItems: function(obj){
    displayProducts(obj);
    },
    
    //returns Domstrings    
    getDOMstrings: function(){
    return DOMstrings;
    },
    
    //delete product by id    
    deleteListItem: function(selectorID){
    var el = document.getElementById(selectorID);
    el.parentNode.removeChild(el);
    },
    //method to update message when no products available in shopping cart
    //method to update number of item in hedaer
    updateMessage: function(data){
      //display no products message    
    if(data.products.length < 1){
    document.getElementById(DOMstrings.productList).innerHTML=" ";
    document.getElementById(DOMstrings.productList).style.borderBottom="none";
    document.getElementById(DOMstrings.messageId).style.display="block";
    }
    //update no of products
    if(data.products.length >= 1){
    document.getElementById(DOMstrings.noOfItems).innerHTML = data.products.length + " ITEMS";   
    }},    
    //display product overlay    
    displayOverlay:function(prod){
    var modal = document.getElementById(DOMstrings.overlayId);
    var span = document.getElementsByClassName(DOMstrings.close)[0];
    modal.style.display = "block";
    span.onclick = function(){
    modal.style.display = "none";
    window.onclick = function(event) {
    if (event.target == modal) {
    modal.style.display = "none";
                  }
            }
    }
    //assign prod size, quantity to size,quantity drop down
    document.getElementById(DOMstrings.selctSizeId).value=prod.size;
    document.getElementById(DOMstrings.selectQuantityId).value=prod.quantity;
        console.log(prod.overlayImage);
    document.getElementById(DOMstrings.overlayImageId).src=prod.overlayImage;
    document.getElementsByClassName('title')[0].innerHTML=prod.title;
    document.getElementsByClassName('price')[0].innerHTML="<sup>$</sup>"+prod.price;
    document.getElementsByClassName('color')[0].innerHTML=prod.color;    
    },
        
    //display updated product on page    
    displayUpdatedProducts: function(obj){
    obj.products.forEach(function(cur){
    displayProducts(cur) ;
         
    }); 
      
    },
   //display total     
    displayTotal: function(total){
     document.getElementById(DOMstrings.total).innerHTML="<sup>$</sup>"+total.toFixed(2);
     document.getElementById(DOMstrings.estimatedTotal).innerHTML="<sup>$</sup>"+total.toFixed(2);
    }    
        
    };
    })();



    // GLOBAL APP CONTROLLER
    var controller = (function(prodCtrl,UICtrl){
        
    //Get Dom strings   
    var DOM = UICtrl.getDOMstrings();
        
    //Method to set up event listeners    
    var setupEventListeners = function(){
    //set event on remove button of each product 
    document.querySelectorAll(DOM.removebutton).
    forEach(function(cur){
    cur.addEventListener('click',ctrlDeleteProduct)                                           
    });
    //set event on edit button of each product 
    document.querySelectorAll(DOM.editbutton).forEach(function(cur){
    cur.addEventListener('click',displayOverlay)
    });
    //set event on overlay edit button of each product     
    document.querySelectorAll(DOM.editOverlay).forEach(function(cur){
    cur.addEventListener('click',updateProduct)
    });
    }
    
    //Delete item on click of remove button
    var ctrlDeleteProduct= function(event){
    var itemID = event.target.parentNode.parentNode.parentNode.id;
    if(itemID){
    //delete the item from the data structure
    var data = prodCtrl.deleteItem(itemID);
    
    //Delete the item from the UI
    UICtrl.deleteListItem(itemID);
    UICtrl.updateMessage(data);    
    }
    } ;  
   
    
    //Display overlay on click of edit button    
    var displayOverlay= function(event){
    var itemID,prod;
    itemID = event.target.parentNode.parentNode.parentNode.id;
    if(itemID){
    prod = prodCtrl.getProductByID(itemID);
    }
    UICtrl.displayOverlay(prod);
    document.querySelector(DOM.editOverlay).id=itemID;
    };
    
    //Update product after edit    
    var updateProduct=function(event){
    var id = document.querySelector(DOM.editOverlay).id;
    var prod = prodCtrl.getProductByID(id);
    prod.size = document.getElementById(DOM.selctSizeId).value;
    prod.quantity= document.getElementById(DOM.selectQuantityId).value;
    //update data structure
    var data=prodCtrl.updateProductDetails(id,prod.size,prod.quantity);
    //update UI
    data.products.forEach(function(cur){
            UICtrl.deleteListItem(cur.id);
        });
   
    UICtrl.displayUpdatedProducts(data);
     //calculate and display total    
    var total=prodCtrl.calculateTotal();
    UICtrl.displayTotal(total);     
    setupEventListeners();
    };
    
    
    return{
    //loading product list on page load   
    init:function(){
    console.log('This is your shopping Cart'); 
    document.getElementById('noProducts').style.display="none"; 
    var data=prodCtrl.addProduct();
    data.products.forEach(function(cur){
    UICtrl.displayProdItems(cur);
    //calculate and display total    
    var total=prodCtrl.calculateTotal();
    UICtrl.displayTotal(total); 
    });
    setupEventListeners();
     }
     };
     })(productController,UIController);
    controller.init();



